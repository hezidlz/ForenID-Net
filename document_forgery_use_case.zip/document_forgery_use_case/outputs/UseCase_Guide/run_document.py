"""Single-image entry point for the selected full-image + two 512px crop scheme.

Run with the project's work/trufor-venv/bin/python. The original repository,
weights, inference script, Apple Vision binary and calibration lock are required.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
INFER = ROOT / 'outputs/FantasyID_TruFor_expanded/infer.py'
ROUND = ROOT / 'outputs/FantasyID_TruFor_round2'
VISION = ROOT / 'work/trufor_research/detect_text'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def select_two(weighted, boxes, original_size):
    """Preserve the existing candidate order and separation rule; stop at two."""
    old = load_module('guide_region_helpers', ROOT / 'outputs/FantasyID_TruFor_expanded/build_modules.py')
    h, w = weighted.shape
    ow, oh = original_size
    if min(ow, oh) < 768:
        raise ValueError('Original width and height must both be at least 768 pixels')
    candidates = []
    for box in boxes:
        x0, y0, x1, y1 = old.pixel_rect(box, w, h)
        if (x1 - x0) * (y1 - y0) >= 16:
            candidates.append(dict(cx=(x0+x1)/2/w, cy=(y0+y1)/2/h,
                                   priority=float(weighted[y0:y1, x0:x1].mean()), source='text'))
    candidates.sort(key=lambda v: -v['priority'])
    fallback = []
    for cy in np.linspace(384, oh-384, 3):
        for cx in np.linspace(384, ow-384, 4):
            x0, x1 = int((cx-384)/ow*w), int((cx+384)/ow*w)
            y0, y1 = int((cy-384)/oh*h), int((cy+384)/oh*h)
            fallback.append(dict(cx=cx/ow, cy=cy/oh,
                priority=float(weighted[y0:y1, x0:x1].mean()), source='grid_fallback'))
    candidates += sorted(fallback, key=lambda v: -v['priority'])
    regions = []
    for c in candidates:
        x0 = int(np.clip(round(c['cx']*ow)-384, 0, ow-768))
        y0 = int(np.clip(round(c['cy']*oh)-384, 0, oh-768))
        if any(np.hypot(x0-v['x0'], y0-v['y0']) < 384 for v in regions):
            continue
        regions.append(dict(x0=x0, y0=y0, x1=x0+768, y1=y0+768,
                            selection_source=c['source'], selection_priority=c['priority']))
        if len(regions) == 2:
            return regions
    raise ValueError('Cannot select two regions with the required 384px separation')


def predict(folder, output, device):
    subprocess.run([sys.executable, str(INFER), '--input', str(folder),
                    '--output', str(output), '--device', device, '--threads', '4'], check=True)


def read_prediction(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k].copy() for k in z.files}


def save_heatmap(values, path):
    from matplotlib import colormaps
    rgb = np.round(colormaps['turbo'](np.clip(values, 0, 1))[..., :3] * 255).astype(np.uint8)
    Image.fromarray(rgb).save(path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True, help='One upright JPG or PNG image')
    p.add_argument('--output', required=True, help='New or empty output directory')
    p.add_argument('--device', choices=['mps', 'cpu'], default='mps')
    a = p.parse_args()
    source, out = Path(a.input).resolve(), Path(a.output).resolve()
    lock = json.loads((ROUND / 'calibration_lock.json').read_text())
    if lock['selected'] != 'fine512':
        raise ValueError('This entry point requires the selected fine512 scheme')
    if lock['protocol_sha256'] != digest(ROUND / 'protocol.json'):
        raise ValueError('Protocol hash does not match the calibration lock')
    if not VISION.is_file():
        raise FileNotFoundError(f'Apple Vision executable is missing: {VISION}')
    if out.exists() and any(out.iterdir()):
        raise ValueError('Use a new or empty output directory')
    with Image.open(source) as opened:
        if opened.format not in ['JPEG', 'PNG']:
            raise ValueError('Input must be a JPEG or PNG image')
        if opened.getexif().get(274, 1) != 1:
            raise ValueError('Export an upright image without an EXIF rotation flag first')
        original = opened.convert('RGB')
    if min(original.size) < 768:
        raise ValueError('Original width and height must both be at least 768 pixels')
    for name in ['global_input', 'global_predictions', 'crops', 'crop_predictions', 'heatmaps']:
        (out / name).mkdir(parents=True, exist_ok=True)
    scale = 1536 / max(original.size)
    full = original.resize(tuple(round(d * scale) for d in original.size), Image.Resampling.LANCZOS)
    full_path = out / 'global_input/image.png'
    full.save(full_path)
    subprocess.run([str(VISION), str(out/'global_input'), str(out/'text_boxes.json')], check=True)
    boxes = json.loads((out/'text_boxes.json').read_text())['results'][0]
    if boxes['error']:
        raise RuntimeError(f"Apple Vision failed: {boxes['error']}")
    predict(out/'global_input', out/'global_predictions', a.device)
    global_pred = read_prediction(out/'global_predictions/image.png.npz')
    expected = json.loads((ROUND/'protocol.json').read_text())['checkpoint_sha256']
    if str(global_pred['checkpoint_sha256']) != expected:
        raise ValueError('Checkpoint differs from the selected evaluation scheme')
    regions = select_two(global_pred['map'] * global_pred['conf'], boxes['boxes'], original.size)
    crops = []
    for i, region in enumerate(regions):
        x0 = int(np.clip(region['x0']+384-256, 0, original.width-512))
        y0 = int(np.clip(region['y0']+384-256, 0, original.height-512))
        path = out/f'crops/crop_{i}.png'
        original.crop((x0, y0, x0+512, y0+512)).save(path)
        crops.append(dict(index=i, x0=x0, y0=y0, x1=x0+512, y1=y0+512,
                          path=str(path.relative_to(out)), sha256=digest(path),
                          selection_region=region))
    predict(out/'crops', out/'crop_predictions', a.device)
    save_heatmap(global_pred['map'], out/'heatmaps/global_map.png')
    save_heatmap(global_pred['conf'], out/'heatmaps/global_conf.png')
    for crop in crops:
        i = crop['index']
        pred = read_prediction(out/f'crop_predictions/crop_{i}.png.npz')
        crop.update(score=float(pred['score']), prediction_path=f'crop_predictions/crop_{i}.png.npz')
        save_heatmap(pred['map'], out/f'heatmaps/crop_{i}_map.png')
        save_heatmap(pred['conf'], out/f'heatmaps/crop_{i}_conf.png')
    threshold = lock['metrics']['fine512']['threshold']
    g = float(global_pred['score'])
    score = (g + max(c['score'] for c in crops)) / 2
    result = dict(input=str(source), input_sha256=digest(source), original_size=list(original.size),
                  global_size=list(full.size), scheme='fine512', device=a.device,
                  global_score=g, crops=crops, final_score=score, threshold=threshold,
                  prediction='forged' if score >= threshold else 'genuine',
                  checkpoint_sha256=expected, calibration_lock_sha256=digest(ROUND/'calibration_lock.json'),
                  coordinates='Original decoded image pixels; top-left origin; x1/y1 exclusive',
                  heatmap_scale='turbo fixed to [0,1]; high value is warm; map and conf are separate')
    preview = full.copy()
    draw = ImageDraw.Draw(preview)
    for crop in crops:
        box = (round(crop['x0']/original.width*full.width), round(crop['y0']/original.height*full.height),
               round(crop['x1']/original.width*full.width), round(crop['y1']/original.height*full.height))
        draw.rectangle(box, outline=(255,100,0) if crop['index'] == 0 else (0,180,220), width=5)
        draw.text((box[0]+6, box[1]+6), f"ROI {crop['index']}", fill=(0,0,0), stroke_fill=(255,255,255), stroke_width=2)
    preview.save(out/'regions.png')
    (out/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(final_score=score, threshold=threshold, prediction=result['prediction'],
                          result=str(out/'result.json')), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
