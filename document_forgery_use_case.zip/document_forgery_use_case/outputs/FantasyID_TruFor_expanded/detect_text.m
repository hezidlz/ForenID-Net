#import <Foundation/Foundation.h>
#import <Vision/Vision.h>

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc != 3) return 2;
        NSString *input = @(argv[1]);
        NSString *output = @(argv[2]);
        NSError *error = nil;
        NSArray *files = [[[NSFileManager defaultManager] contentsOfDirectoryAtPath:input error:&error]
                          sortedArrayUsingSelector:@selector(compare:)];
        if (error) { NSLog(@"%@", error); return 1; }
        NSMutableArray *rows = [NSMutableArray array];
        for (NSString *name in files) {
            if (![name hasSuffix:@".png"]) continue;
            @autoreleasepool {
                NSURL *url = [NSURL fileURLWithPath:[input stringByAppendingPathComponent:name]];
                VNDetectTextRectanglesRequest *request = [[VNDetectTextRectanglesRequest alloc] init];
                request.reportCharacterBoxes = NO;
                VNImageRequestHandler *handler = [[VNImageRequestHandler alloc] initWithURL:url options:@{}];
                NSError *requestError = nil;
                [handler performRequests:@[request] error:&requestError];
                NSMutableArray *boxes = [NSMutableArray array];
                for (VNTextObservation *observation in request.results) {
                    CGRect b = observation.boundingBox;
                    [boxes addObject:@{@"x":@(CGRectGetMinX(b)), @"y_top":@(1-CGRectGetMaxY(b)),
                        @"width":@(CGRectGetWidth(b)), @"height":@(CGRectGetHeight(b)),
                        @"confidence":@(observation.confidence)}];
                }
                [rows addObject:@{@"filename":name, @"boxes":boxes,
                    @"error":requestError ? requestError.description : [NSNull null]}];
                printf("%lu %s boxes=%lu\n", (unsigned long)rows.count, name.UTF8String, (unsigned long)boxes.count);
                fflush(stdout);
            }
        }
        NSDictionary *result = @{@"detector":@"Apple Vision VNDetectTextRectanglesRequest",
            @"revision":@(VNDetectTextRectanglesRequest.defaultRevision),
            @"os":[NSProcessInfo processInfo].operatingSystemVersionString,
            @"coordinates":@"normalized top-left origin", @"results":rows};
        NSData *data = [NSJSONSerialization dataWithJSONObject:result options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:&error];
        if (!data || ![data writeToFile:output options:NSDataWritingAtomic error:&error]) { NSLog(@"%@",error); return 1; }
    }
    return 0;
}
