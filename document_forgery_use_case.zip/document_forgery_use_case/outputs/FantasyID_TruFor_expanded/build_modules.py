"""Fixed train-free features and native-resolution crop selection; never reads labels."""
from pathlib import Path
import argparse,hashlib,json,time,zipfile
import numpy as np
from PIL import Image

BASE=Path(__file__).resolve().parent

def topmean(a,fraction):
    x=np.asarray(a).ravel()
    if not x.size:return None
    k=max(1,int(np.ceil(x.size*fraction)))
    return float(np.partition(x,x.size-k)[-k:].mean())

def pixel_rect(box,w,h):
    x0=max(0,int(np.floor(box['x']*w)));y0=max(0,int(np.floor(box['y_top']*h)))
    x1=min(w,int(np.ceil((box['x']+box['width'])*w)));y1=min(h,int(np.ceil((box['y_top']+box['height'])*h)))
    return x0,y0,x1,y1

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--wait',action='store_true');args=parser.parse_args()
    # Only sample_id/paths/dimensions are used. Labels and splits do not affect features.
    samples=sorted(json.loads((BASE/'manifest.json').read_text())['samples'],key=lambda r:r['sample_id'])
    boxes={r['filename']:r for r in json.loads((BASE/'text_boxes.json').read_text())['results']}
    features=[]
    for idx,r in enumerate(samples):
        sid=r['sample_id'];filename=Path(r['input_path']).name
        prediction=BASE/'predictions'/(filename+'.npz')
        wait_start=time.monotonic()
        while True:
            try:
                with np.load(prediction,allow_pickle=False) as z:
                    loc=z['map'];conf=z['conf'];g=float(z['score'])
                break
            except (FileNotFoundError,zipfile.BadZipFile,EOFError):
                if not args.wait or time.monotonic()-wait_start>600:raise
                time.sleep(1)
        weighted=loc*conf;h,w=loc.shape
        bx,by=max(1,int(w*.02)),max(1,int(h*.02))
        local=topmean(weighted[by:-by,bx:-bx],.01)
        text_mask=np.zeros((h,w),dtype=bool);candidates=[]
        for box in boxes[filename]['boxes']:
            x0,y0,x1,y1=pixel_rect(box,w,h)
            if x1<=x0 or y1<=y0:continue
            text_mask[y0:y1,x0:x1]=True
            if (x1-x0)*(y1-y0)>=16:
                candidates.append(dict(cx=(x0+x1)/2/w,cy=(y0+y1)/2/h,
                    priority=float(weighted[y0:y1,x0:x1].mean()),source='text'))
        text=topmean(weighted[text_mask],.1)
        if text is None:text=g
        candidates.sort(key=lambda v:-v['priority'])
        ow,oh=r['original_width'],r['original_height']
        # Fixed-grid fallback uses the same weighted map, without label-dependent decisions.
        fallback=[]
        for cy in np.linspace(384,oh-384,3):
            for cx in np.linspace(384,ow-384,4):
                x0=int((cx-384)/ow*w);x1=int((cx+384)/ow*w)
                y0=int((cy-384)/oh*h);y1=int((cy+384)/oh*h)
                fallback.append(dict(cx=cx/ow,cy=cy/oh,priority=float(weighted[y0:y1,x0:x1].mean()),source='grid_fallback'))
        candidates+=sorted(fallback,key=lambda v:-v['priority'])
        crops=[]
        with Image.open(BASE/r['original_path']) as original:
            original=original.convert('RGB')
            for c in candidates:
                x0=int(np.clip(round(c['cx']*ow)-384,0,ow-768))
                y0=int(np.clip(round(c['cy']*oh)-384,0,oh-768))
                if any(np.hypot(x0-v['x0'],y0-v['y0'])<384 for v in crops):continue
                crop_id=sid+f'__crop{len(crops)}';path=BASE/'native_crops'/(crop_id+'.png')
                original.crop((x0,y0,x0+768,y0+768)).save(path)
                crops.append(dict(crop_id=crop_id,path=str(path.relative_to(BASE)),x0=x0,y0=y0,x1=x0+768,y1=y0+768,
                                  selection_source=c['source'],selection_priority=c['priority'],sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
                if len(crops)==2:break
        assert len(crops)==2
        features.append(dict(sample_id=sid,global_score=g,local_conf=local,text_conf=text,
            text_boxes=len(boxes[filename]['boxes']),text_pixel_fraction=float(text_mask.mean()),text_error=boxes[filename]['error'],crops=crops))
        print(f'{idx+1}/{len(samples)} {sid} boxes={len(boxes[filename]["boxes"])} crops=2',flush=True)
    (BASE/'module_features.json').write_text(json.dumps(features,indent=2)+'\n')

if __name__=='__main__':main()
