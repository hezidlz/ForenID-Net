"""Run unchanged TruFor weights on CPU/MPS; preserve raw outputs and provenance."""
import argparse,hashlib,json,os,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'outputs/TruFor/TruFor_train_test'

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--device',choices=['mps','cpu'],default='mps');p.add_argument('--threads',type=int,default=4)
    a=p.parse_args();inp=Path(a.input).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
    files=sorted(inp.glob('*.png'))
    if not files:raise RuntimeError('No input PNG files')
    torch.set_num_threads(a.threads);sys.path.insert(0,str(SOURCE));os.chdir(SOURCE)
    from lib.config import config
    from lib.utils import get_model
    config.defrost();config.merge_from_file(str(SOURCE/'lib/config/trufor_ph3.yaml'));config.freeze()
    weight=SOURCE/'pretrained_models/trufor.pth.tar'
    sha=hashlib.sha256(weight.read_bytes()).hexdigest()
    allowed=[np.core.multiarray.scalar,np.dtype,type(np.dtype(np.float64)),type(np.dtype(np.float32))]
    with torch.serialization.safe_globals(allowed):
        ck=torch.load(weight,map_location='cpu',weights_only=True)
    model=get_model(config);model.load_state_dict(ck['state_dict']);model.eval();model.to(a.device)
    del ck
    results=[];start=time.perf_counter()
    for i,f in enumerate(files):
        sha_in=hashlib.sha256(f.read_bytes()).hexdigest();target=out/(f.name+'.npz')
        if not target.exists():
            im=np.array(Image.open(f).convert('RGB'))
            rgb=torch.from_numpy(im.transpose(2,0,1).copy()).float().unsqueeze(0).to(a.device)/256.0
            began=time.perf_counter()
            with torch.no_grad():
                pred,conf,det,_=model(rgb,save_np=False)
                loc=torch.softmax(pred[0],dim=0)[1].cpu().numpy()
                con=torch.sigmoid(conf[0,0]).cpu().numpy()
                score=torch.sigmoid(det).item()
            if a.device=='mps':torch.mps.synchronize()
            seconds=time.perf_counter()-began
            np.savez(target,map=loc,conf=con,score=score,imgsize=im.shape[:2],input_sha256=sha_in,
                     checkpoint_sha256=sha,device=a.device,inference_seconds=seconds)
            del rgb,pred,conf,det,loc,con
            if a.device=='mps':torch.mps.empty_cache()
        with np.load(target,allow_pickle=False) as z:
            assert str(z['input_sha256'])==sha_in and str(z['checkpoint_sha256'])==sha
            assert str(z['device'])==a.device
            for key in ['map','conf']:
                assert z[key].shape==tuple(z['imgsize']) and np.isfinite(z[key]).all()
                assert z[key].min()>=0 and z[key].max()<=1
            assert np.isfinite(z['score']) and 0<=float(z['score'])<=1
            row=dict(image=str(f),prediction=str(target),score=float(z['score']),seconds=float(z['inference_seconds']))
        results.append(row)
        print(json.dumps(dict(done=i+1,total=len(files),**row)),flush=True)
    report=dict(device=a.device,torch=torch.__version__,threads=a.threads,checkpoint_sha256=sha,
                weights_updated=False,elapsed_seconds_after_model_load=time.perf_counter()-start,results=results)
    (out/'run_summary.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
