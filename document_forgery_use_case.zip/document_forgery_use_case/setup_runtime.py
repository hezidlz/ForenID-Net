"""Build the local text detector and verify or download the model checkpoint."""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
WEIGHT = ROOT/'outputs/TruFor/TruFor_train_test/pretrained_models/trufor.pth.tar'
URL = 'https://www.grip.unina.it/download/prog/TruFor/TruFor_weights.zip'


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=Path,help='Use an existing trufor.pth.tar instead of downloading')
    p.add_argument('--sdk',type=Path,help='Optional macOS SDK path for the local clang toolchain')
    a=p.parse_args()
    if platform.system()!='Darwin':raise SystemExit('This entry point requires macOS Apple Vision')
    expected=json.loads((ROOT/'outputs/FantasyID_TruFor_round2/protocol.json').read_text())['checkpoint_sha256']
    WEIGHT.parent.mkdir(parents=True,exist_ok=True)
    if WEIGHT.exists():
        if digest(WEIGHT)!=expected:raise SystemExit('Existing checkpoint hash mismatch; use the matching checkpoint')
    elif a.checkpoint:
        source=a.checkpoint.resolve()
        if digest(source)!=expected:raise SystemExit('Supplied checkpoint hash mismatch')
        shutil.copyfile(source,WEIGHT)
    else:
        work=ROOT/'work';work.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='weights-',dir=work) as tmp:
            archive=Path(tmp)/'weights.zip'
            print('Downloading official checkpoint archive',flush=True)
            urllib.request.urlretrieve(URL,archive)
            with zipfile.ZipFile(archive) as z:
                members=[n for n in z.namelist() if Path(n).name=='trufor.pth.tar']
                if len(members)!=1:raise SystemExit('Expected one trufor.pth.tar in the official archive')
                staged=Path(tmp)/'trufor.pth.tar'
                with z.open(members[0]) as src,staged.open('wb') as dst:shutil.copyfileobj(src,dst)
                if digest(staged)!=expected:raise SystemExit('Downloaded checkpoint hash mismatch')
                shutil.copyfile(staged,WEIGHT)
    detector=ROOT/'work/trufor_research/detect_text';detector.parent.mkdir(parents=True,exist_ok=True)
    sdk_args=['-isysroot',str(a.sdk.resolve())] if a.sdk else []
    subprocess.run(['clang',*sdk_args,'-O2','-fobjc-arc',str(ROOT/'outputs/FantasyID_TruFor_expanded/detect_text.m'),
        '-framework','Foundation','-framework','Vision','-framework','CoreGraphics','-o',str(detector)],check=True)
    print(json.dumps({'checkpoint_sha256':expected,'text_detector':str(detector)},indent=2))

if __name__=='__main__':main()
