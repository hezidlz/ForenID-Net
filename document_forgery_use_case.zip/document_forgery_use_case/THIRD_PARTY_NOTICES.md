# Third-party notices

This use case is based on TruFor by Fabrizio Guillaro, Davide Cozzolino, Avneesh Sud, Nicholas Dufour and Luisa Verdoliva, CVPR 2023.

- Official source: https://github.com/grip-unina/TruFor
- Source commit: `ae54475df6f41a491d7615100feb19263dec13f7`
- Paper: https://openaccess.thecvf.com/content/CVPR2023/html/Guillaro_TruFor_Leveraging_All-Round_Clues_for_Trustworthy_Image_Forgery_Detection_and_CVPR_2023_paper.html

The included upstream `lib/` source files retain their original copyright notices. The original TruFor and CMX license texts are preserved in `outputs/TruFor/TruFor_train_test/`. The TruFor software and weights remain subject to its informational and nonprofit-use terms; CMX portions retain their own license.

The presentation and guide contain an illustrative FantasyID sample and a TruFor architecture figure with attribution in the presentation notes. Dataset source: https://arxiv.org/abs/2507.20808 . Scores are from a third-party mirror subset. No raw dataset image files are included in this source package. Model weights are retrieved separately from the official source and verified by SHA-256.
