# 证件伪造检测与定位交付材料

本目录包含最终方案的 Project conclusion PPT、Use case guide，以及对应的单张图像推理代码与评测分数。方案基于 TruFor，使用全图检测和两个 512 × 512 原图裁块复检。

## 材料

- [Project conclusion PPT](materials/证件伪造检测与定位_最终方案版.pptx)：13 页，六部分结构。
- [Use case guide](materials/证件伪造检测与定位_Use_case_guide.docx)：5 页，说明模型使用、代码与结果解读。
- [单张调用入口](outputs/UseCase_Guide/run_document.py)
- [最终方案配置与阈值](outputs/FantasyID_TruFor_round2/calibration_lock.json)
- [200 张测试分数](results/selected_scores.json)与[指标](results/selected_evaluation.json)

## 安装与运行

以下命令从本目录执行。该流程使用 macOS Apple Vision 和 Apple Silicon MPS；需要 Python 3.11，以及可用的 `clang` 编译器。推理依赖采用项目验证过的版本清单。

```bash
cd document_forgery_use_case
python3.11 -m venv work/trufor-venv
work/trufor-venv/bin/python -m pip install -r outputs/TruFor_local/requirements-lock.txt
work/trufor-venv/bin/python setup_runtime.py
```

`setup_runtime.py` 从官方来源下载模型权重并校验 SHA-256，同时编译文字区域检测器。如果已有权重，可避免重复下载：

```bash
work/trufor-venv/bin/python setup_runtime.py --checkpoint /path/to/trufor.pth.tar
```

如果本机编译器与默认 SDK 不兼容，可通过 `setup_runtime.py --sdk /path/to/MacOSX.sdk` 指定与编译器匹配的已安装 SDK。本机验证使用 MacOSX15.4.sdk。

输入一张方向正确的 JPG 或 PNG 图片；原图宽高均至少 768 像素，且能够选择两个满足间距约束的区域。输出目录应为新目录或空目录。

```bash
work/trufor-venv/bin/python outputs/UseCase_Guide/run_document.py \
  --input /path/to/document.jpg \
  --output work/result_001 \
  --device mps
```

Word 中的命令在该目录下保持相同相对路径。Word 示范中的 FantasyID 原图由使用者按数据许可另行取得；仓库不附原始数据集。把示范命令的 `--input` 改成自己的图片路径即可。

输出 `result.json`、`regions.png`、全图和裁块 `.npz` 预测以及分别表示 `map` 与 `conf` 的热图。`forged` 表示模型判为伪造，`genuine` 表示模型判为真图；热图表示模型响应。

## 最终方案与结果

- 全图：RGB，LANCZOS 长边 1536；模型归一化 `/256.0`。
- 选区：文字框内 `mean(map * conf)` 排序，追加 3 × 4 网格候选；768 选择窗口左上角间距至少 384 原图像素。
- 局部：按前两个窗口中心分别裁出 512 × 512 原图区域。
- 融合：`S = (G + max(p1, p2)) / 2`。
- 判定：`S >= 0.5488707721233369` 时判为伪造。

| 测试集 | TPR | FAR | FRR | AUC |
|---|---:|---:|---:|---:|
| 同来源 200 张，真伪各 100 张 | 90% | 10% | 7% | 0.9687 |

FAR 指伪造图被判为真图的比例，FRR 指真图被判为伪造的比例。评测使用 FantasyID 第三方镜像标签；图像哈希不重复，但身份和模板独立性未建立。该子集没有像素级真值，因此不报告 IoU 或 Dice。

只使用保存的逐图分数即可复算指标，不需要加载权重：

```bash
python3.11 verify_results.py
```

该校验还会复算 PPT 中四个 FAR 工作点的 FRR。工作点来自同一测试集上的事后阈值扫描，不替代固定推理阈值。

## 代码与来源

本目录保持指南中的相对路径。官方模型推理所需 `lib/` 源码已包含；大权重由安装脚本单独下载。最终配置和逐图分数导出仅保留 `fine512`，阈值和最终指标与原实验一致。

- `outputs/UseCase_Guide/run_document.py`：输入处理、选区、裁块、融合与可视化。
- `outputs/FantasyID_TruFor_expanded/infer.py`：官方模型加载与原始预测。
- `outputs/FantasyID_TruFor_expanded/build_modules.py`：文字框像素坐标转换等选区辅助函数。
- `outputs/FantasyID_TruFor_expanded/detect_text.m`：Apple Vision 文字区域检测器。
- `setup_runtime.py`：权重校验与文字检测器编译。
- `verify_results.py`：根据已保存分数复算最终指标。

指南中的 `experiment.py` 和 `verify.py` 描述原实验的组织与核验流程；本次交付通过单张入口和 `verify_results.py` 提供对应的使用与指标复算功能。

模型源码版本、权重哈希及原作者信息见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) 与 `outputs/FantasyID_TruFor_round2/protocol.json`。保留原始许可证；使用条件依原作者条款。
