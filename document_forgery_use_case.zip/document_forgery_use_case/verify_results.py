"""Recompute the selected scheme's image-level results from the saved scores."""
from pathlib import Path
import json
import math

ROOT=Path(__file__).resolve().parent

def main():
    rows=json.loads((ROOT/'results/selected_scores.json').read_text())
    expected=json.loads((ROOT/'results/selected_evaluation.json').read_text())['fresh']
    lock=json.loads((ROOT/'outputs/FantasyID_TruFor_round2/calibration_lock.json').read_text())
    threshold=lock['metrics']['fine512']['threshold']
    assert len(rows)==200 and len({r['sample_id'] for r in rows})==200
    for r in rows:
        assert r['label_manipulated'] in (0,1)
        for k in ['global_score','crop_512_0','crop_512_1','fine512']:
            assert math.isfinite(r[k]) and 0<=r[k]<=1
        assert abs((r['global_score']+max(r['crop_512_0'],r['crop_512_1']))/2-r['fine512'])<1e-12
    fake=[r['fine512'] for r in rows if r['label_manipulated']]
    real=[r['fine512'] for r in rows if not r['label_manipulated']]
    assert len(fake)==len(real)==100
    tp=sum(s>=threshold for s in fake);fp=sum(s>=threshold for s in real)
    auc=sum((a>b)+.5*(a==b) for a in fake for b in real)/(len(fake)*len(real))
    measured=dict(tp=tp,fn=len(fake)-tp,fp=fp,tn=len(real)-fp,tpr=tp/len(fake),far=(len(fake)-tp)/len(fake),frr=fp/len(real),auc=auc)
    for k,v in measured.items():assert abs(v-expected[k])<1e-12,(k,v,expected[k])
    points=[]
    thresholds=sorted(set(fake+real))
    for target in [.05,.02,.01,.001]:
        feasible=[t for t in thresholds if sum(s<t for s in fake)/len(fake)<=target]
        t=max(feasible)
        far=sum(s<t for s in fake)/len(fake);frr=sum(s>=t for s in real)/len(real)
        points.append(dict(target_far=target,empirical_far=far,frr=frr,threshold=t))
    assert [p['frr'] for p in points]==[.25,.37,.42,.5]
    print(json.dumps(dict(passed=True,threshold=threshold,fixed_threshold=measured,posthoc_operating_points=points),indent=2))

if __name__=='__main__':main()
